// Génère des cartes en français à partir de Wikidata (données dans le domaine public, licence CC0).
// Lancé par GitHub à chaque compilation. Si Wikidata ne répond pas, l'appli garde simplement ses autres cartes.
import { writeFileSync } from 'node:fs';

const SORTIE = new URL('../www/wikidata.js', import.meta.url);
const POINT = 'https://query.wikidata.org/sparql';
const ENTETES = { 'User-Agent': 'PiocheApp/1.0 (appli personnelle de cartes de révision)', Accept: 'application/sparql-results+json' };

async function requete(nom, sparql) {
  for (let essai = 1; essai <= 3; essai++) {
    try {
      const rep = await fetch(POINT + '?format=json&query=' + encodeURIComponent(sparql), { headers: ENTETES, signal: AbortSignal.timeout(90000) });
      if (!rep.ok) throw new Error('HTTP ' + rep.status);
      const json = await rep.json();
      const lignes = json.results.bindings.map((b) => Object.fromEntries(Object.entries(b).map(([k, v]) => [k, v.value])));
      console.log(`${nom} : ${lignes.length} lignes`);
      return lignes;
    } catch (e) {
      console.log(`${nom} : essai ${essai} raté (${e.message})`);
      await new Promise((r) => setTimeout(r, 4000 * essai));
    }
  }
  return [];
}

const PAYS = `?pays wdt:P31 wd:Q3624078 ; wikibase:sitelinks ?liens .
  FILTER NOT EXISTS { ?pays wdt:P576 ?dissous }`;
const ACTUEL = (p) => `?pays p:${p} ?st . ?st ps:${p} ?val . FILTER NOT EXISTS { ?st pq:P582 ?fin }
  ?st wikibase:rank ?rang . FILTER(?rang != wikibase:DeprecatedRank)`;
const LABELS = 'SERVICE wikibase:label { bd:serviceParam wikibase:language "fr". }';

// ---------- Outils ----------
const estLabel = (s) => s && !/^Q\d+$/.test(s) && !/^https?:/.test(s);
const maj = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const melanger = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
function leurres(bonne, proches, tous) {
  const vus = new Set([bonne.toLowerCase()]); const res = [];
  for (const v of melanger(proches).concat(melanger(tous))) {
    if (res.length === 3) break;
    if (!v || vus.has(v.toLowerCase())) continue;
    vus.add(v.toLowerCase()); res.push(v);
  }
  return res.length === 3 ? res : null;
}
// Les plus connus (beaucoup d'articles Wikipédia) sont classés faciles
function difficultes(items, partFacile = 0.35) {
  const tri = items.slice().sort((a, b) => b.liens - a.liens);
  const seuil = Math.floor(tri.length * partFacile);
  tri.forEach((it, i) => { it.d = i < seuil ? 1 : 2; });
}
// Regroupe les lignes par entité, en gardant les valeurs distinctes
function regrouper(lignes, cle, champs) {
  const m = new Map();
  for (const l of lignes) {
    if (!m.has(l[cle])) m.set(l[cle], { liens: +(l.liens || 0), ...Object.fromEntries(champs.map((c) => [c, new Set()])), base: l });
    const it = m.get(l[cle]);
    for (const c of champs) if (estLabel(l[c])) it[c].add(l[c]);
  }
  return [...m.values()];
}

const cartes = [];
const ajouter = (t, d, q, a, x, e = '') => { if (x) cartes.push([t, d, q, a, x, e]); };

// ---------- 1. Capitales et continents ----------
const CONTINENTS = { 'Europe': 'Europe', 'Asie': 'Asie', 'Afrique': 'Afrique', 'Amérique du Nord': 'Amérique du Nord', 'Amérique du Sud': 'Amérique du Sud', 'Océanie': 'Océanie', 'Australie': 'Océanie', 'Antarctique': 'Antarctique' };
{
  const lignes = await requete('Capitales', `SELECT ?pays ?paysLabel ?valLabel ?continentLabel ?liens WHERE {
    ${PAYS} ${ACTUEL('P36')} OPTIONAL { ?pays wdt:P30 ?continent } ${LABELS} }`);
  const pays = regrouper(lignes, 'pays', ['valLabel', 'continentLabel']).filter((p) => estLabel(p.base.paysLabel));
  difficultes(pays);
  const toutesCapitales = pays.filter((p) => p.valLabel.size === 1).map((p) => [...p.valLabel][0]);
  for (const p of pays) {
    const nom = maj(p.base.paysLabel);
    const conts = [...new Set([...p.continentLabel].map((c) => CONTINENTS[c]).filter(Boolean))];
    if (p.valLabel.size === 1) {
      const cap = [...p.valLabel][0];
      if (cap.toLowerCase() !== nom.toLowerCase()) {
        const proches = pays.filter((o) => o !== p && o.valLabel.size === 1 && [...o.continentLabel].some((c) => conts.includes(CONTINENTS[c]))).map((o) => [...o.valLabel][0]);
        ajouter('G', p.d, `${nom} : quelle est sa capitale ?`, cap, leurres(cap, proches, toutesCapitales));
      }
    }
    if (conts.length === 1) {
      ajouter('G', 1, `${nom} : sur quel continent se trouve ce pays ?`, conts[0], leurres(conts[0], [], ['Europe', 'Asie', 'Afrique', 'Amérique du Nord', 'Amérique du Sud', 'Océanie']));
    }
  }
}

// ---------- 2. Monnaies ----------
{
  const lignes = await requete('Monnaies', `SELECT ?pays ?paysLabel ?valLabel ?liens WHERE { ${PAYS} ${ACTUEL('P38')} ${LABELS} }`);
  const pays = regrouper(lignes, 'pays', ['valLabel']).filter((p) => estLabel(p.base.paysLabel) && p.valLabel.size === 1);
  difficultes(pays);
  const toutes = [...new Set(pays.map((p) => maj([...p.valLabel][0])))];
  for (const p of pays) {
    const m = maj([...p.valLabel][0]);
    ajouter('W', p.d, `${maj(p.base.paysLabel)} : quelle est sa monnaie ?`, m, leurres(m, [], toutes));
  }
}

// ---------- 3. Éléments chimiques ----------
{
  const lignes = await requete('Éléments', `SELECT ?el ?elLabel ?sym ?num WHERE {
    ?el wdt:P31 wd:Q11344 ; wdt:P246 ?sym ; wdt:P1086 ?num . FILTER(?num <= 92) ${LABELS} }`);
  const vus = new Map();
  for (const l of lignes) if (estLabel(l.elLabel) && !vus.has(l.el)) vus.set(l.el, { nom: maj(l.elLabel), sym: l.sym, num: Math.round(+l.num) });
  const els = [...vus.values()];
  const noms = els.map((e) => e.nom), syms = els.map((e) => e.sym);
  for (const e of els) {
    const d = e.num <= 30 ? 1 : 2;
    ajouter('S', d, `Quel élément chimique a pour symbole « ${e.sym} » ?`, e.nom, leurres(e.nom, [], noms), `Numéro atomique ${e.num}.`);
    ajouter('S', d, `${e.nom} : quel est son symbole chimique ?`, e.sym, leurres(e.sym, syms.filter((s) => s[0] === e.sym[0]), syms));
  }
}

// ---------- 4. Départements français ----------
{
  const lignes = await requete('Départements', `SELECT ?dep ?depLabel ?code ?prefLabel WHERE {
    ?dep wdt:P31 wd:Q6465 ; wdt:P2586 ?code . FILTER NOT EXISTS { ?dep wdt:P576 ?fin }
    OPTIONAL { ?dep wdt:P36 ?pref } ${LABELS} }`);
  const deps = regrouper(lignes, 'dep', ['prefLabel', 'code']).filter((d) => estLabel(d.base.depLabel));
  const tousNoms = deps.map((d) => maj(d.base.depLabel));
  const prefs = deps.filter((d) => d.prefLabel.size === 1).map((d) => [...d.prefLabel][0]);
  for (const d of deps) {
    const nom = maj(d.base.depLabel);
    const codes = [...d.code].filter((c) => /^(\d{2,3}|2A|2B)$/.test(c));
    if (codes.length === 1) ajouter('G', 2, `Quel département porte le numéro ${codes[0]} ?`, nom, leurres(nom, [], tousNoms));
    if (d.prefLabel.size === 1) {
      const p = [...d.prefLabel][0];
      if (p !== nom) ajouter('G', 2, `${nom} : quelle est la préfecture de ce département ?`, p, leurres(p, [], prefs));
    }
  }
}

// ---------- 5. Œuvres littéraires célèbres ----------
{
  const lignes = await requete('Livres', `SELECT ?livre ?livreLabel ?auteur ?auteurLabel ?liens WHERE {
    ?livre wdt:P31 wd:Q7725634 ; wdt:P50 ?auteur ; wikibase:sitelinks ?liens . FILTER(?liens >= 45) ${LABELS} }`);
  const livres = regrouper(lignes, 'livre', ['auteurLabel']).filter((l) => estLabel(l.base.livreLabel) && l.auteurLabel.size === 1);
  difficultes(livres, 0.3);
  const auteurs = [...new Set(livres.map((l) => [...l.auteurLabel][0]))];
  for (const l of livres) {
    const a = [...l.auteurLabel][0];
    if (/anonyme|inconnu/i.test(a)) continue;
    ajouter('A', l.d, `Qui a écrit « ${l.base.livreLabel} » ?`, a, leurres(a, [], auteurs));
  }
}

// ---------- 6. Tableaux célèbres ----------
{
  const lignes = await requete('Tableaux', `SELECT ?oeuvre ?oeuvreLabel ?peintre ?peintreLabel ?liens WHERE {
    ?oeuvre wdt:P31 wd:Q3305213 ; wdt:P170 ?peintre ; wikibase:sitelinks ?liens . FILTER(?liens >= 25) ${LABELS} }`);
  const oeuvres = regrouper(lignes, 'oeuvre', ['peintreLabel']).filter((o) => estLabel(o.base.oeuvreLabel) && o.peintreLabel.size === 1);
  difficultes(oeuvres, 0.3);
  const peintres = [...new Set(oeuvres.map((o) => [...o.peintreLabel][0]))].filter((p) => !/anonyme|inconnu/i.test(p));
  for (const o of oeuvres) {
    const p = [...o.peintreLabel][0];
    if (/anonyme|inconnu/i.test(p)) continue;
    ajouter('A', o.d, `Qui a peint « ${o.base.oeuvreLabel} » ?`, p, leurres(p, [], peintres));
  }
}

// ---------- Écriture ----------
const uniques = [...new Map(cartes.map((c) => [c[2], c])).values()];
writeFileSync(SORTIE, '// Généré automatiquement depuis Wikidata (CC0) le ' + new Date().toISOString().slice(0, 10) + '\nwindow.PIOCHE_WIKI = ' + JSON.stringify(uniques) + ';\n');
console.log(`Total : ${uniques.length} cartes Wikidata écrites`);
