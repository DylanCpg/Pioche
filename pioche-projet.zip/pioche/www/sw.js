// Fait marcher Pioche hors connexion. Le numéro de version est remplacé à chaque publication par GitHub.
const CACHE = 'pioche-__VERSION__';
const FICHIERS = ['./', 'index.html', 'style.css', 'app.js', 'data.js', 'data-plus.js', 'wikidata.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(FICHIERS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((cles) => Promise.all(cles.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
// Réseau d'abord : la dernière version s'affiche dès qu'il y a internet, sinon on prend la copie enregistrée.
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(
    fetch(e.request).then((rep) => {
      if (rep.ok) { const copie = rep.clone(); caches.open(CACHE).then((c) => c.put(e.request, copie)); }
      return rep;
    }).catch(() => caches.match(e.request).then((r) => r || caches.match('index.html')))
  );
});
