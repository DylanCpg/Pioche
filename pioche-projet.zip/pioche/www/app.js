(function () {
  'use strict';

  // ---------- Données ----------
  var THEMES = window.PIOCHE_THEMES;
  var CATS = window.PIOCHE_CATEGORIES;
  var COUPLE = window.PIOCHE_COUPLE;
  var NB_WIKI = 0;
  var CARTES = (function () {
    var vus = {}, res = [];
    function prendre(c, wiki) {
      var id = 'c' + hash(c[2]);
      if (vus[id] || !c[4] || c[4].length < 3) return;
      vus[id] = 1; if (wiki) NB_WIKI++;
      res.push({ id: id, t: c[0], d: c[1], q: c[2], a: c[3], x: c[4], e: c[5] || '' });
    }
    window.PIOCHE_CARTES.forEach(function (c) { prendre(c, false); });
    (window.PIOCHE_WIKI || []).forEach(function (c) { prendre(c, true); });
    return res;
  })();
  var NIVEAUX = { 1: [1], 2: [1, 2], 3: [2, 3] };
  var NOMS_NIVEAUX = { 1: 'Léger', 2: 'Curieux', 3: 'Profond' };
  var INTERVALLES = [0, 1, 3, 7, 16, 35];
  var MOTS = ['MIEL', 'LUNE', 'ROSE', 'CERF', 'NUIT', 'VENT', 'BLÉ', 'CHAT', 'LOUP', 'PAIN', 'SOIE', 'IRIS', 'LIME', 'COCO', 'ÉTÉ', 'MAÏS', 'PRUNE', 'OURS', 'SEL', 'THÉ'];
  MOTS = MOTS.map(function (m) { return m.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); });

  // ---------- Stockage ----------
  var CLE = 'pioche.v1';
  var store = charger();
  function defaut() {
    return { prog: {}, serie: { n: 0, dernier: -1 }, perso: [], partie: null,
      prefs: { themes: ['H', 'S', 'E'], diff: 'mix', mode: 'cartes', n: 20 },
      couple: { niveau: 2, masque: 0x7f } };
  }
  function charger() {
    try {
      var s = JSON.parse(localStorage.getItem(CLE));
      if (s && s.prog) { var d = defaut(); for (var k in d) if (!(k in s)) s[k] = d[k]; return s; }
    } catch (e) {}
    return defaut();
  }
  function sauver() { try { localStorage.setItem(CLE, JSON.stringify(store)); } catch (e) {} }

  // ---------- Utilitaires ----------
  function hash(str) {
    var h = 1779033703 ^ str.length;
    for (var i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
    h = Math.imul(h ^ (h >>> 16), 2246822507); h = Math.imul(h ^ (h >>> 13), 3266489909);
    return ((h ^= h >>> 16) >>> 0).toString(36);
  }
  function graine(str) {
    var a = parseInt(hash(str), 36) >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0; var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function melanger(arr, rnd) {
    rnd = rnd || Math.random; var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function jour() { var d = new Date(); return Math.floor((d.getTime() - d.getTimezoneOffset() * 60000) / 86400000); }
  function nomTheme(id) { if (id === 'M') return 'Mes cartes'; for (var i = 0; i < THEMES.length; i++) if (THEMES[i].id === id) return THEMES[i].nom; return ''; }
  function toutesCartes() {
    return CARTES.concat(store.perso.map(function (p) { return { id: p.id, t: 'M', d: 1, q: p.q, a: p.a, x: null, e: '' }; }));
  }
  function aRevoir() {
    var j = jour(), n = 0, ids = {};
    toutesCartes().forEach(function (c) { ids[c.id] = 1; });
    for (var id in store.prog) if (ids[id] && store.prog[id].due <= j) n++;
    return n;
  }
  function serieActuelle() { var s = store.serie; return (s.dernier >= jour() - 1) ? s.n : 0; }
  function noterJour() {
    var j = jour(), s = store.serie;
    if (s.dernier === j) return;
    s.n = (s.dernier === j - 1) ? s.n + 1 : 1; s.dernier = j;
  }
  function noter(carte, ok) {
    var p = store.prog[carte.id] || { b: 0, due: 0 };
    p.b = ok ? Math.min(p.b + 1, INTERVALLES.length - 1) : 0;
    p.due = jour() + INTERVALLES[p.b];
    store.prog[carte.id] = p; noterJour(); sauver();
  }

  var ICONES = {
    retour: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
    fermer: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    reglages: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>'
  };
  function entete(titre, action, icone, label) {
    return '<div class="entete"><button class="rond" data-a="' + action + '" aria-label="' + label + '">' + ICONES[icone] + '</button><h2>' + titre + '</h2></div>';
  }

  // ---------- État temporaire ----------
  var session = null;   // { mode, cartes, i, retournee, choix, options, bons, total, rejouees }
  var erreurCode = '';

  // ---------- Navigation ----------
  function aller(route) { if (location.hash !== '#' + route) history.pushState(null, '', '#' + route); rendre(); }
  window.addEventListener('popstate', rendre);
  window.addEventListener('hashchange', rendre);

  function rendre() {
    var r = location.hash.replace('#', '') || 'accueil';
    if ((r === 'session' || r === 'bilan') && !session) r = 'apprendre';
    if (r === 'partie' && !store.partie) r = 'couple';
    var vues = { accueil: vAccueil, apprendre: vApprendre, session: vSession, bilan: vBilan, couple: vCouple, partie: vPartie, perso: vPerso, reglages: vReglages };
    var v = vues[r] || vAccueil;
    document.body.className = (r === 'couple' || r === 'partie') ? 'couple' : '';
    document.getElementById('app').innerHTML = v();
    window.scrollTo(0, 0);
  }

  // ---------- Vues ----------
  function vAccueil() {
    var h = new Date().getHours();
    var salut = h < 6 ? 'Bonne nuit' : h < 18 ? 'Bonjour' : 'Bonsoir';
    var serie = serieActuelle(), rev = aRevoir();
    var info = serie > 0
      ? '<div class="carte-info"><div class="pastille">' + serie + '</div><div><b>' + (serie > 1 ? 'Jours d’affilée' : 'Premier jour de série') + '</b><p class="petit">' + (rev ? rev + ' carte' + (rev > 1 ? 's' : '') + ' à revoir aujourd’hui' : 'Rien à revoir aujourd’hui') + '</p></div></div>'
      : '<div class="carte-info"><div class="pastille">0</div><div><b>Pas encore de série</b><p class="petit">Fais quelques cartes pour la lancer.</p></div></div>';
    return '<div class="entete"><h2 style="font-size:26px">Pioche</h2><button class="rond" data-a="nav:reglages" aria-label="Réglages">' + ICONES.reglages + '</button></div>' +
      '<div><p class="doux">' + salut + '</p><h1>On pioche quoi ?</h1></div>' + info +
      '<button class="tuile indigo" data-a="nav:apprendre"><span class="sur">Apprendre</span><span><strong>Cartes et quiz</strong><span class="desc">Histoire, sciences, géographie… un seul thème ou un grand mélange.</span></span></button>' +
      '<button class="tuile rose" data-a="nav:couple"><span class="sur">À deux</span><span><strong>Se découvrir</strong><span class="desc">Chacun sur son téléphone, les mêmes questions dans le même ordre.</span></span></button>' +
      '<div class="bas"><button class="btn second" data-a="rapide">Mélange rapide de 10 cartes</button></div>';
  }

  function vApprendre() {
    var p = store.prefs;
    var themes = THEMES.slice(); if (store.perso.length) themes.push({ id: 'M', nom: 'Mes cartes' });
    var puces = themes.map(function (t) { return '<button class="puce" data-a="theme:' + t.id + '" aria-pressed="' + (p.themes.indexOf(t.id) >= 0) + '">' + esc(t.nom) + '</button>'; }).join('');
    var seg = function (cle, vals) { return '<div class="segment">' + vals.map(function (v) { return '<button data-a="' + cle + ':' + v[0] + '" aria-pressed="' + (String(p[cle]) === String(v[0])) + '">' + v[1] + '</button>'; }).join('') + '</div>'; };
    var nb = construire(true).length;
    return entete('Apprendre', 'nav:accueil', 'retour', 'Retour') +
      '<p class="doux">Choisis un ou plusieurs thèmes, les cartes se mélangent.</p>' +
      '<div class="puces">' + puces + '<button class="puce" data-a="tous">Tout</button></div>' +
      '<div class="bloc"><span class="lbl">Difficulté</span>' + seg('diff', [['facile', 'Facile'], ['mix', 'Mélange'], ['moyen', 'Moyen']]) + '</div>' +
      '<div class="bloc"><span class="lbl">Mode</span><div class="choix2">' +
      '<button class="option" data-a="mode:cartes" aria-pressed="' + (p.mode === 'cartes') + '"><b>Cartes</b><span class="petit">Tu retournes, tu dis si tu savais.</span></button>' +
      '<button class="option" data-a="mode:quiz" aria-pressed="' + (p.mode === 'quiz') + '"><b>Quiz</b><span class="petit">Quatre choix, un score à la fin.</span></button></div></div>' +
      '<div class="bloc"><span class="lbl">Nombre de cartes</span>' + seg('n', [[10, '10'], [20, '20'], [40, '40']]) + '</div>' +
      '<div class="bas">' + (nb ? '' : '<p class="erreur">Aucune carte ne correspond. Ajoute un thème ou change la difficulté.</p>') +
      '<button class="btn" data-a="commencer"' + (nb ? '' : ' disabled') + '>Commencer · ' + Math.min(nb, p.n) + ' carte' + (Math.min(nb, p.n) > 1 ? 's' : '') + '</button>' +
      '<button class="lien" data-a="nav:perso">Gérer mes cartes</button></div>';
  }

  function construire(compter, opts) {
    var p = opts || store.prefs, j = jour();
    var perso = store.perso;
    var pool = toutesCartes().filter(function (c) {
      if (p.themes.indexOf(c.t) < 0) return false;
      if (p.diff === 'facile' && c.d !== 1) return false;
      if (p.diff === 'moyen' && c.d !== 2) return false;
      if (p.mode === 'quiz' && c.t === 'M' && perso.length < 4) return false;
      return true;
    });
    if (compter) return pool;
    var dues = [], neuves = [], autres = [];
    melanger(pool).forEach(function (c) {
      var pr = store.prog[c.id];
      if (!pr) neuves.push(c); else if (pr.due <= j) dues.push(c); else autres.push(c);
    });
    dues.sort(function (a, b) { return store.prog[a.id].b - store.prog[b.id].b; });
    return dues.concat(neuves, autres).slice(0, p.n);
  }

  function demarrer(opts) {
    var cartes = melanger(construire(false, opts));
    if (!cartes.length) return;
    session = { mode: (opts || store.prefs).mode, cartes: cartes, i: 0, retournee: false, choix: null, options: null, bons: 0, total: cartes.length, rejouees: {} };
    preparerOptions(); aller('session');
  }
  function preparerOptions() {
    var c = session.cartes[session.i]; session.choix = null; session.retournee = false; session.options = null;
    if (session.mode !== 'quiz' || !c) return;
    var faux = c.x;
    if (!faux) faux = melanger(store.perso.filter(function (p) { return p.a !== c.a; }).map(function (p) { return p.a; })).slice(0, 3);
    session.options = melanger([c.a].concat(faux));
  }

  function vSession() {
    var s = session, c = s.cartes[s.i];
    var pct = Math.round((s.i / s.cartes.length) * 100);
    var haut = '<div class="progres"><button class="rond" data-a="nav:apprendre" aria-label="Arrêter la session">' + ICONES.fermer + '</button><div class="barre" role="progressbar" aria-valuenow="' + pct + '" aria-valuemin="0" aria-valuemax="100"><i style="width:' + pct + '%"></i></div><span class="score">' + (s.i + 1) + '/' + s.cartes.length + '</span></div>';
    var tags = '<div class="etiquettes"><span class="tag">' + esc(nomTheme(c.t)) + '</span><span class="petit">' + (c.d === 1 ? 'Facile' : 'Moyen') + '</span></div>';
    if (s.mode === 'cartes') {
      var corps = s.retournee
        ? '<div class="sep"></div><div class="apparait" style="display:flex;flex-direction:column;gap:10px"><span class="petit">Réponse</span><div class="reponse">' + esc(c.a) + '</div>' + (c.e ? '<p class="doux">' + esc(c.e) + '</p>' : '') + '</div>'
        : '<p class="indice">Touche la carte pour voir la réponse</p>';
      return haut + '<button class="flash" data-a="retourner" aria-label="' + (s.retournee ? 'Carte retournée' : 'Retourner la carte') + '">' + tags + '<span class="question">' + esc(c.q) + '</span>' + corps + '</button>' +
        (s.retournee ? '<div class="duo"><button class="revoir" data-a="juge:0">À revoir</button><button class="savais" data-a="juge:1">Je savais</button></div>' : '<div class="duo" aria-hidden="true" style="visibility:hidden"><button tabindex="-1">.</button></div>');
    }
    var opts = s.options.map(function (o, k) {
      var cls = '';
      if (s.choix !== null) { if (o === c.a) cls = 'juste'; else if (k === s.choix) cls = 'faux'; }
      return '<button class="' + cls + '" data-a="choix:' + k + '"' + (s.choix !== null ? ' disabled' : '') + '>' + esc(o) + '</button>';
    }).join('');
    var verdict = '';
    if (s.choix !== null) {
      var ok = s.options[s.choix] === c.a;
      verdict = '<div class="verdict apparait"><b class="' + (ok ? 'ok' : 'ko') + '">' + (ok ? 'Bonne réponse' : 'La bonne réponse était : ' + esc(c.a)) + '</b>' + (c.e ? '<p class="doux">' + esc(c.e) + '</p>' : '') + '</div>' +
        '<div class="bas"><button class="btn" data-a="suivante">' + (s.i + 1 < s.cartes.length ? 'Question suivante' : 'Voir mon score') + '</button></div>';
    }
    return haut.replace('<span class="score">', '<span class="score">Score ' + s.bons + ' · ').replace(/(\d+)\/(\d+)<\/span>/, '$1/$2</span>') +
      '<div style="display:flex;flex-direction:column;gap:12px">' + tags + '<span class="question">' + esc(c.q) + '</span></div><div class="qcm">' + opts + '</div>' + verdict;
  }

  function vBilan() {
    var s = session, pct = s.total ? Math.round(s.bons / s.total * 100) : 0;
    var msg = pct >= 80 ? 'Excellent, tu maîtrises.' : pct >= 50 ? 'Pas mal, les cartes ratées reviendront bientôt.' : 'Les cartes ratées reviendront plus souvent, c’est comme ça qu’on apprend.';
    return entete('Session terminée', 'nav:accueil', 'fermer', 'Fermer') +
      '<div class="flash" style="align-items:center;justify-content:center;text-align:center;min-height:300px"><div class="gros-score">' + s.bons + '/' + s.total + '</div><p class="doux">' + (s.mode === 'quiz' ? 'bonnes réponses' : 'cartes sues du premier coup') + '</p><p>' + msg + '</p></div>' +
      '<div class="bas"><button class="btn" data-a="encore">Rejouer avec les mêmes réglages</button><button class="btn second" data-a="nav:accueil">Retour à l’accueil</button></div>';
  }

  function vCouple() {
    var c = store.couple, code = genererCode(c.niveau, c.masque);
    var puces = CATS.map(function (k) { return '<button class="puce" data-a="cat:' + k.id + '" aria-pressed="' + !!(c.masque & (1 << k.id)) + '">' + esc(k.nom) + '</button>'; }).join('');
    var nb = poolCouple(c.niveau, c.masque).length;
    var reprise = store.partie ? '<button class="btn second" data-a="nav:partie">Reprendre la partie ' + esc(store.partie.code) + '</button>' : '';
    return entete('Se découvrir', 'nav:accueil', 'retour', 'Retour') +
      '<div class="code"><span class="p">Code de la partie, à taper sur l’autre téléphone</span><span class="grand">' + code + '</span><span class="p">Les deux téléphones tirent les mêmes questions, dans le même ordre.</span></div>' +
      '<div class="ou">ou rejoindre une partie</div>' +
      '<div class="bloc"><div class="ligne-saisie"><label class="sr" for="code">Code reçu</label><input class="champ" id="code" autocapitalize="characters" autocomplete="off" placeholder="Code reçu"><button class="btn-contour" data-a="rejoindre">Rejoindre</button></div>' + (erreurCode ? '<p class="erreur">' + erreurCode + '</p>' : '') + '</div>' +
      '<div class="bloc"><span class="lbl">Ambiance</span><div class="segment">' + [1, 2, 3].map(function (n) { return '<button data-a="niveau:' + n + '" aria-pressed="' + (c.niveau === n) + '">' + NOMS_NIVEAUX[n] + '</button>'; }).join('') + '</div></div>' +
      '<div class="bloc"><span class="lbl">Catégories</span><div class="puces">' + puces + '</div></div>' +
      '<div class="bas">' + reprise + '<button class="btn" data-a="lancer"' + (nb ? '' : ' disabled') + '>Lancer la partie · ' + nb + ' questions</button></div>';
  }

  var codeDuJour = null;
  function genererCode(niveau, masque) {
    if (!codeDuJour) codeDuJour = MOTS[Math.floor(Math.random() * MOTS.length)];
    return codeDuJour + '-' + niveau + ('0' + masque.toString(16).toUpperCase()).slice(-2);
  }
  function lireCode(txt) {
    var t = txt.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s-]/g, '');
    var m = t.match(/^([A-Z]{2,6})([123])([0-9A-F]{2})$/);
    if (!m) return null;
    var masque = parseInt(m[3], 16) & 0x7f;
    if (!masque) return null;
    return { code: m[1] + '-' + m[2] + m[3], niveau: +m[2], masque: masque };
  }
  function poolCouple(niveau, masque) {
    var niv = NIVEAUX[niveau];
    return COUPLE.filter(function (q) { return (masque & (1 << q[0])) && niv.indexOf(q[1]) >= 0; });
  }
  function questionsPartie(p) { return melanger(poolCouple(p.niveau, p.masque), graine(p.code)); }

  function vPartie() {
    var p = store.partie, qs = questionsPartie(p);
    if (p.i >= qs.length) {
      return entete('Partie terminée', 'quitter', 'fermer', 'Quitter la partie') +
        '<div class="flash" style="align-items:center;justify-content:center;text-align:center;min-height:300px"><div class="gros-score" style="color:var(--rose)">' + p.score + '/' + p.vues + '</div><p class="doux">réponses devinées</p><p>Comparez vos scores !</p></div>' +
        '<div class="bas"><button class="btn" data-a="quitter">Nouvelle partie</button></div>';
    }
    var q = qs[p.i];
    return '<div class="entete"><button class="rond" data-a="nav:couple" aria-label="Retour aux réglages de la partie">' + ICONES.fermer + '</button><h2 style="font-size:15px;font-family:var(--texte);font-weight:600;color:var(--doux)">' + esc(p.code) + ' · question ' + (p.i + 1) + ' sur ' + qs.length + '</h2><span class="score">' + p.score + ' devinée' + (p.score > 1 ? 's' : '') + '</span></div>' +
      '<div class="flash" style="min-height:0;border-color:var(--rose-ligne)"><div class="etiquettes"><span class="tag">' + esc(CATS[q[0]].nom) + '</span><span class="petit">' + NOMS_NIVEAUX[q[1]] + '</span></div><span class="question">' + esc(q[2]) + '</span></div>' +
      '<div class="bloc"><label class="lbl" for="moi">Ma réponse</label><textarea class="champ" id="moi" rows="2"></textarea></div>' +
      '<div class="bloc"><label class="lbl" for="devine">Ce que l’autre va répondre, à ton avis</label><textarea class="champ" id="devine" rows="2"></textarea></div>' +
      '<div class="encart"><p>Lisez vos réponses à voix haute. Est-ce que tu avais deviné ?</p><div class="duo"><button class="rate" data-a="devine:0">Raté</button><button class="bienvu" data-a="devine:1">Bien vu</button></div></div>' +
      '<div class="bas"><button class="lien" style="color:var(--rose);text-align:center" data-a="passer">Passer cette question</button></div>';
  }

  function vPerso() {
    var items = store.perso.map(function (p) {
      return '<div class="item"><div><b>' + esc(p.q) + '</b><span class="petit">' + esc(p.a) + '</span></div><button class="rond" data-a="suppr:' + p.id + '" aria-label="Supprimer cette carte">' + ICONES.fermer + '</button></div>';
    }).join('');
    return entete('Mes cartes', 'nav:apprendre', 'retour', 'Retour') +
      '<p class="doux">Ajoute ce que tu veux retenir : vocabulaire, permis, formation… Il en faut au moins 4 pour le mode quiz.</p>' +
      '<div class="bloc"><label class="lbl" for="pq">Question</label><textarea class="champ" id="pq" rows="2"></textarea></div>' +
      '<div class="bloc"><label class="lbl" for="pa">Réponse</label><input class="champ" id="pa"></div>' +
      '<p class="erreur" id="perr" hidden>Remplis la question et la réponse.</p>' +
      '<button class="btn" data-a="ajouter">Ajouter la carte</button>' +
      (items ? '<div class="liste">' + items + '</div>' : '<p class="petit">Aucune carte pour l’instant.</p>');
  }

  function vReglages() {
    return entete('Réglages', 'nav:accueil', 'retour', 'Retour') +
      '<div class="bloc"><span class="lbl">Ma progression</span><p class="doux">' + Object.keys(store.prog).length + ' cartes déjà vues, ' + store.perso.length + ' carte(s) perso.</p><button class="btn second" data-a="raz">Effacer ma progression</button></div>' +
      '<div class="bloc"><span class="lbl">Contenu</span><p class="doux">' + CARTES.length + ' cartes d’apprentissage et ' + COUPLE.length + ' questions à deux.' + (NB_WIKI ? ' ' + NB_WIKI + ' cartes sont générées automatiquement à partir de Wikidata, une base de connaissances libre (CC0).' : '') + '</p></div>' +
      '<div class="bloc"><span class="lbl">À propos</span><p class="doux">Pioche, version 1.2. Tout reste sur ton téléphone, rien n’est envoyé en ligne.</p></div>';
  }

  // ---------- Actions ----------
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-a]'); if (!el || el.disabled) return;
    var a = el.getAttribute('data-a'), i = a.indexOf(':'), cmd = i < 0 ? a : a.slice(0, i), arg = i < 0 ? '' : a.slice(i + 1);
    var p = store.prefs;
    switch (cmd) {
      case 'nav': erreurCode = ''; aller(arg); return;
      case 'theme': var k = p.themes.indexOf(arg); if (k >= 0) p.themes.splice(k, 1); else p.themes.push(arg); break;
      case 'tous': var ids = THEMES.map(function (t) { return t.id; }); if (store.perso.length) ids.push('M'); p.themes = p.themes.length === ids.length ? [] : ids; break;
      case 'diff': p.diff = arg; break;
      case 'mode': p.mode = arg; break;
      case 'n': p.n = +arg; break;
      case 'commencer': sauver(); demarrer(); return;
      case 'rapide': demarrer({ themes: THEMES.map(function (t) { return t.id; }), diff: 'mix', mode: 'cartes', n: 10 }); return;
      case 'retourner': if (!session.retournee) { session.retournee = true; rendre(); } return;
      case 'juge':
        var c = session.cartes[session.i], ok = arg === '1';
        noter(c, ok);
        if (ok && !session.rejouees[c.id]) session.bons++;
        if (!ok && !session.rejouees[c.id]) { session.rejouees[c.id] = 1; session.cartes.push(c); }
        suivante(); return;
      case 'choix':
        session.choix = +arg; var cc = session.cartes[session.i], bon = session.options[session.choix] === cc.a;
        if (bon) session.bons++; noter(cc, bon); rendre(); return;
      case 'suivante': suivante(); return;
      case 'encore': demarrer(session.opts || null); return;
      case 'niveau': store.couple.niveau = +arg; break;
      case 'cat': var m = store.couple.masque ^ (1 << +arg); store.couple.masque = m; break;
      case 'lancer':
        var cp = store.couple; store.partie = { code: genererCode(cp.niveau, cp.masque), niveau: cp.niveau, masque: cp.masque, i: 0, score: 0, vues: 0 };
        codeDuJour = null; sauver(); aller('partie'); return;
      case 'rejoindre':
        var lu = lireCode(document.getElementById('code').value);
        if (!lu) { erreurCode = 'Ce code n’est pas valide. Il ressemble à MIEL-27F.'; rendre(); return; }
        erreurCode = ''; store.partie = { code: lu.code, niveau: lu.niveau, masque: lu.masque, i: 0, score: 0, vues: 0 }; sauver(); aller('partie'); return;
      case 'devine': store.partie.vues++; if (arg === '1') store.partie.score++; store.partie.i++; sauver(); rendre(); return;
      case 'passer': store.partie.i++; sauver(); rendre(); return;
      case 'quitter': store.partie = null; sauver(); aller('couple'); return;
      case 'ajouter':
        var q = document.getElementById('pq').value.trim(), r = document.getElementById('pa').value.trim();
        if (!q || !r) { document.getElementById('perr').hidden = false; return; }
        store.perso.push({ id: 'p' + Date.now().toString(36), q: q, a: r });
        if (p.themes.indexOf('M') < 0) p.themes.push('M');
        break;
      case 'suppr': store.perso = store.perso.filter(function (x) { return x.id !== arg; }); delete store.prog[arg]; break;
      case 'raz': if (confirm('Effacer toute ta progression ? Tes cartes perso sont conservées.')) { store.prog = {}; store.serie = { n: 0, dernier: -1 }; } break;
      default: return;
    }
    sauver(); rendre();
  });
  document.addEventListener('input', function (ev) {
    if (ev.target.id === 'pq' || ev.target.id === 'pa') { var e = document.getElementById('perr'); if (e) e.hidden = true; }
    if (ev.target.id === 'code' && erreurCode) { erreurCode = ''; var er = ev.target.closest('.bloc').querySelector('.erreur'); if (er) er.remove(); }
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Enter' && ev.target.id === 'code') { var b = document.querySelector('[data-a="rejoindre"]'); if (b) b.click(); }
  });

  function suivante() {
    session.i++;
    if (session.i >= session.cartes.length) { aller('bilan'); return; }
    preparerOptions(); rendre();
  }

  // On garde les réglages de la session pour « Rejouer »
  var demarrerBase = demarrer;
  demarrer = function (opts) { demarrerBase(opts); if (session) session.opts = opts || null; };

  window.__pioche = { lireCode: lireCode, genererCode: genererCode, questionsPartie: questionsPartie, construire: construire, store: function () { return store; } };
  rendre();
})();
