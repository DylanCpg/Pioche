// Rempli automatiquement par GitHub à chaque publication (cartes Wikidata).
window.PIOCHE_WIKI = [];
