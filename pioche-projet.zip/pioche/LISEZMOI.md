# Pioche

Cartes d'apprentissage et questions pour se découvrir à deux. Comme Caddie : l'appli est un site publié sur GitHub Pages, et l'APK ouvre ce site. Chaque modification envoyée sur GitHub arrive dans l'appli sans rien réinstaller.

## Mise en ligne (une seule fois)

1. Crée un dépôt **public** nommé `pioche` (GitHub Pages gratuit demande un dépôt public).
2. « Add file » > « Upload files » : envoie `pioche-projet.zip` tel quel, sans le dézipper, puis « Commit changes ».
3. « Settings » > « Pages » > « Source » : choisis **GitHub Actions**.
4. « Add file » > « Create new file » : nom `.github/workflows/site.yml`, colle le contenu du fichier `site.yml`, puis « Commit changes ».
5. Onglet « Actions » : quand la coche est verte, l'appli est en ligne à `https://TON-NOM.github.io/pioche/`.

## Obtenir l'APK (une seule fois)

1. Ouvre pwabuilder.com et colle l'adresse du site.
2. « Package for stores » > « Android », garde la clé de signature sur « New », télécharge le paquet.
3. Extrais le zip et installe le fichier `.apk`. Garde le zip : il contient la clé de signature.

Tu peux aussi simplement ouvrir le site dans Chrome, puis ⋮ > « Ajouter à l'écran d'accueil ».

## Mettre à jour

Envoie le nouveau `pioche-projet.zip` (même nom) ou modifie un fichier directement sur GitHub. Le site est republié tout seul. Dans l'appli, ferme-la complètement et rouvre-la avec internet : la nouvelle version s'affiche.

Il ne faut refaire l'APK que pour changer le nom ou l'icône de l'appli.

## D'où viennent les cartes

- `www/data.js` et `www/data-plus.js` : cartes et questions écrites pour Pioche.
- `www/wikidata.js` : cartes générées depuis Wikidata (CC0) à chaque publication. Si Wikidata ne répond pas, le site est publié quand même.

## Ajouter des cartes

Dans `www/data.js` ou `www/data-plus.js` :
- une carte : `['H',1,'Question ?','Réponse',['Faux 1','Faux 2','Faux 3'],'Explication facultative'],`
- une question à deux : `[0,2,'Question ?'],` (catégorie de 0 à 6, niveau 1 léger, 2 curieux, 3 profond)
